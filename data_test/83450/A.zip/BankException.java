public class BankException extends Exception {

    public BankException() {

    }

    public BankException(String mess) {
        super(mess);
    }
}
