public class BankException extends Exception {
    BankException(String e) {
        super(e);
    }
}
