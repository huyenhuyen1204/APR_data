public class BankException extends Exception {
    /**
     * Constructor.
     */
    public BankException(String message) {
        super(message);
    }
}