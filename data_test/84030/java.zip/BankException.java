/**
 * class BankException.
 */
public class BankException extends Exception {
    /**
     * constructor.
     * @param exception .
     */
    public BankException(String exception) {
        super(exception);
    }
}
