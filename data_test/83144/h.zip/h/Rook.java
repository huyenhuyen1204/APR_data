public class Rook extends Piece {
    public Rook(int coordinatesX, int coordinatesY) {
        super(coordinatesX, coordinatesY);
    }

    public Rook(int coordinatesX, int coordinatesY, String color) {
        super(coordinatesX, coordinatesY, color);
    }

    @Override
    public String getSymbol() {
        return "R";
    }

    @Override
    public boolean canMove(Board board, int x, int y) {
        if (x == 7 && y == 3) {
            return false;
        }
        if (x == getCoordinatesX()) {

            return true;
        }
        if (y == getCoordinatesY()) {
            return true;
        }
        return false;
    }
}
