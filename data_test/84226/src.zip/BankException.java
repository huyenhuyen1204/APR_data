public class BankException extends Exception {
    public BankException(String E) {
        super(E);
    }
}
