/**
 * Created by CCNE on 03/12/2020.
 */
public class BankException extends java.lang.Exception {

    /**
     * ok.
     */
    public BankException() {
    }

    /**
     * ok.
     */
    public BankException(String message) {
        super(message);
    }

    /**
     * ok.
     */
    public BankException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * ok.
     */
    public BankException(Throwable cause) {
        super(cause);
    }

    /**
     * ok.
     */
    public BankException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
 