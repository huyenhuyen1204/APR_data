/**
 * Created by CCNE on 02/12/2020.
 */
public class BankException extends Exception {
    public BankException(String string) {
        super(string);
    }
}
