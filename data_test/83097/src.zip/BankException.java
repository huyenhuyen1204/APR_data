public class BankException extends Exception {

    public BankException(String messages) {
        super(messages);
    }
}

