/**
 * Created by CCNE on 02/12/2020.
 */
public class BankException extends java.lang.Exception {
    public BankException(String message) {
        super(message);
    }
}
