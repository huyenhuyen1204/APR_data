public class BankException extends Exception {

    /**
     * Yes.
     */
    public BankException(String s) {
        super(s);
    }
}
