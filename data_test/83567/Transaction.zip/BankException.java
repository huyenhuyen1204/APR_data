public class BankException extends Exception{
    /**
     * Constructor.
     */
    public BankException(){

    }

    /**
     * Constructor 2.
     */
    public BankException(String exception){
        super(exception);
    }
}
